Bakken_Shale_Animation_ReadMe

This file can be played on Windows Media Player or QuickTime. 

Four map features are changing over time after you click on "Play":
- Year stamp in upper right corner advances
- Wells appear according to their first production date
- THe total production of oil & gas in graph bottom right advances
- History labels appear 

Wells are symbolized by two attributes:
- Sized per Oil daily rate (values are mean per quarter: 3 months of production / days in quarter)
- Colored by Gas: Oil ratio (mean per quarter as above). The wells with the highest proportion of gas are red, wells with the highest proportion of oil are green.

The first frame of the movie is dated late 2010, After you click PLAY, the movie runs from 1985 to 2010. The speed of the animation goes quickly from 1985-2000, then slows down from 2001-2010 as the pace of drilling picks up.
 
This is an information-rich map animation.  We recommend viewing it several times and/or pausing it periodically.


Data sources:
Wells and production from HPDI
Bakken Shale limit from Helms (2010)
Bakken Shale history from Sonnenberg & Pramudito (2009) and Lefevre (2007)
