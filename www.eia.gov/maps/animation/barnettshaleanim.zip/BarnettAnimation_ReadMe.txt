Barnett_Shale_Animation_ReadMe

This file can be played on Windows Media Player or QuickTime 

Four map features are changing over time after you click on "Play":
- Year stamp in upper right corner advances
- Wells appear according to their first production date
- THe total production of oil & gas in graph bottom right advances
- History bullets appear on left

The first frame of the movie is late 2010. After you press PLAY, the movie runs frkom 1981 to 2010. The speed of the animation goes quickly from 1981-1996, then slows down from 1997-2010 as the pace of drilling picks up.
 
This is an information-rich map animation.  We recommend viewing it several times and/or pausing it periodically.


Data sources:
Wells and production from HPDI
Barnett Shale limit from Pollastro et ak (2007)
Barnett Shale history from Bowker (2007) and Martineau (2007)
