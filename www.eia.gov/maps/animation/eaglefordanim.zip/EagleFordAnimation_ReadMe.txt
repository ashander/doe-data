Eagle Ford_Shale_Animation_ReadMe

This file can be played on Windows Media Player or QuickTime. 

Three map features are changing over time after you click on "Play":
- Year stamp in lower right corner advances
- Wells appear according to their first production date
- THe total production of oil & gas in graph bottom right advances

Wells are symbolized by two attributes:
- Sized per barrels of Oil equivalent daily rate (values are mean per month: 1 month of production / days in month)
- Colored by Gas: Oil ratio (mean per quarter as above). The wells with the highest proportion of gas are red, wells with the highest proportion of oil are green.

The first frame of the movie is dated late 2010, After you click PLAY, the movie runs from 2006 to 2010. The speed of the animation goes quickly from 2006-2008, then slows down from 2009-2010 as the pace of drilling picks up.

The discovery well for the play is a PetroHawk well located in LaSalle County (2008). Production prior to that is minor from vertical wells.
 
This is an information-rich map animation.  We recommend viewing it several times and/or pausing it periodically.


Data sources:
Wells and production from HPDI
Petroleum Windows from Petrohawk, EOG, DI
