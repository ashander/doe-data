Understanding the MicroData Files of Energy-Related Data

The purpose of this readme.txt file is to present information about 
the EIA household and vehicle file to data users. Based on a recommendation
from U.S. DOT, only �100-percent households� and their light-duty
vehicles are contained in EIA�s public-use files; hence, care should
be taken when combining data from National Household Travel Survey
(NHTS) with EIA�s augmented energy and energy-related data to avoid
any misinterpretations. The following files are available as
public-use microdata:

        EIA Household File (hhpub_0464(2005).xls or hhpub_0464(2005).csv) is an EXCEL
        spreadsheet and comma-delimited file that contains table-specific 
        household characteristics and energy-related household variables for 
	21,178 households. Important: To calculate results that compare to those found in this
        report, data users must exclude in their tabulations those households
        that do not have light-duty vehicles. EIA has included a variable,
        HHVEHLC, for that purpose.

        EIA Vehicle File (vehpub_0464(2005).xls or vehpub_0464(2005).csv) is an EXCEL 
        spreadsheet and comma-delimited file that contains table-specific 
        vehicle characteristics and energy-related vehicle variables for 
        42,736 light-duty vehicles that EIA use to calculate the number and 
        type of light-duty passenger vehicles, annual mileage, type of fuel used, 
        and price paid for fuel, all of which are required to measure the consumption 
        and expenditure associated with the nation�s residential travel.

        NHTS Household File - located on
        www.fhwa.dot.gov/policy/ohpi/nhts/index.htm) -
        contains all the households data collected by the NHTS. 
        To identify the households in the national sample of
        �100-percent household� having at least one light-duty passenger
        vehicle (passenger cars, vans, sport utility vehicles, pickup trucks
        and recreational vehicles), use the VEHTYPE and SMPLSRCE variables
        found on the NHTS Vehicle File.

Detailed documentaton of EIA's Augmented Data is found in Appendix D 
Description of Data, which is included in portable document format as 
d0464(2005).pdf.

If you have any questions, please contact:

Mark Schipper on (202) 586-1136 or email on mark.schipper@eia.doe.gov.